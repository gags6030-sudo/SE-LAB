# Lab 5: Static Code Analysis — To-Do List & Task Manager

**Your file:** `todo_manager.py`

Follow the lab handout for the full instructions.

## About the program

A task manager. It adds tasks with a priority and labels, marks them complete, lists pending tasks in priority order, searches by keyword, suggests a task to do next, and saves and exports tasks as JSON.

The starter code contains quality, style, and security issues of the kind Pylint, Bandit, and Flake8 can help identify.

## What to do

1. Run the program and note its output:

   ```
   python todo_manager.py
   ```

2. Install the tools:

   ```
   python -m pip install pylint bandit flake8
   ```

3. Run the analysis and save the reports:

   ```
   python -m pylint todo_manager.py > pylint_report.txt
   python -m bandit -r todo_manager.py > bandit_report.txt
   python -m flake8 todo_manager.py > flake8_report.txt
   ```

4. Document findings in `issues.md`, fix at least four, and rerun all three tools.
5. Answer the reflection questions provided by your instructor in `reflection.md`.

## Deliverables

- `todo_manager.py`: cleaned version.
- `issues.md`: findings and fixes.
- `reflection.md`: reflection responses.
- `reports/before/` and `reports/after/`: analyzer output before and after fixes.

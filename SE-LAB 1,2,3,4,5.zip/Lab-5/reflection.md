# Reflection

**Note:** The provided handout describes reflection as a deliverable but does not include the actual reflection questions. The responses below address four common reflection topics; replace the headings with the instructor's exact prompts if a separate question sheet was provided.

## 1. What is static analysis, and how is it useful?

Static analysis checks source code without running it. It helps identify likely bugs, insecure patterns, and style problems early, before they reach users. It complements tests: an analyzer can flag risky constructs across code paths that a small demo may not exercise, while tests confirm actual behavior.

## 2. How did Pylint, Bandit, and Flake8 contribute differently?

Pylint highlighted correctness and maintainability concerns, including the shared mutable default, inconsistent return behavior, naming, and missing documentation. Bandit drew attention to unsafe pickle loading and shell execution, as well as its warning about the standard pseudo-random generator. Flake8 identified concrete whitespace and formatting violations. Using all three gave broader coverage than relying on one tool.

## 3. Which finding mattered most, and how was it addressed?

The shell-based email helper and pickle deserialization had the clearest security impact: a crafted recipient could affect a shell command, and loading an untrusted pickle can execute code. The unused shell helper was removed because no email service was configured. Pickle was replaced by JSON, and loaded records are checked against the expected task schema.

## 4. What are the limitations of static analysis?

A clean report does not prove that a program is correct or secure. Tools may flag code that is safe in its context, and they cannot fully understand runtime data, deployment settings, or user expectations. The analyzer results were therefore paired with a demo run and direct checks of task creation, completion, persistence, and validation.

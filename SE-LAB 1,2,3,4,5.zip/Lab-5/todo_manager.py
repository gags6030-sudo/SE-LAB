"""Manage to-do tasks and save them as validated JSON."""

import json
import secrets
from datetime import datetime
from typing import Any

TASKS: dict[int, dict[str, Any]] = {}
PRIORITY_ORDER = {"high": 0, "medium": 1, "low": 2}


def add_task(
    title: str,
    priority: str = "medium",
    labels: list[str] | None = None,
) -> int:
    """Add a task and return its unique integer ID."""
    if not title.strip():
        raise ValueError("Task title cannot be empty.")
    if priority not in PRIORITY_ORDER:
        raise ValueError(f"Unsupported priority: {priority}")
    if labels is not None and (
        not isinstance(labels, list)
        or any(not isinstance(label, str) for label in labels)
    ):
        raise ValueError("Task labels must be a list of strings.")

    task_id = max(TASKS, default=0) + 1
    task_labels = list(labels) if labels is not None else []
    if priority not in task_labels:
        task_labels.append(priority)
    TASKS[task_id] = {
        "title": title,
        "priority": priority,
        "done": False,
        "created": datetime.now().isoformat(),
        "labels": task_labels,
    }
    return task_id


def complete_task(task_id: int) -> bool:
    """Mark a task complete, returning whether its ID exists."""
    if task_id in TASKS:
        TASKS[task_id]["done"] = True
        return True
    print("No task with id", task_id)
    return False


def pending_tasks() -> list[str]:
    """Return incomplete task titles in priority order."""
    pending = [task for task in TASKS.values() if not task["done"]]
    pending.sort(key=lambda task: PRIORITY_ORDER[task["priority"]])
    return [task["title"] for task in pending]


def find_task(keyword: str) -> int | None:
    """Return the ID of the first title containing keyword, if any."""
    normalized_keyword = keyword.casefold()
    for task_id, task in TASKS.items():
        if normalized_keyword in task["title"].casefold():
            return task_id
    return None


def _is_valid_task(task: Any) -> bool:
    """Return whether a decoded JSON object matches the task schema."""
    if not isinstance(task, dict):
        return False
    if not isinstance(task.get("title"), str):
        return False
    if task.get("priority") not in PRIORITY_ORDER:
        return False
    if not isinstance(task.get("done"), bool):
        return False
    if not isinstance(task.get("created"), str):
        return False
    labels = task.get("labels")
    return isinstance(labels, list) and all(
        isinstance(label, str) for label in labels
    )


def save_tasks(file_name: str = "tasks.json") -> None:
    """Save tasks as JSON, which does not execute code when loaded."""
    with open(file_name, "w", encoding="utf-8") as task_file:
        json.dump(TASKS, task_file, indent=2, ensure_ascii=False)


def load_tasks(file_name: str = "tasks.json") -> dict[int, dict[str, Any]]:
    """Load and validate a JSON task file before returning its contents."""
    with open(file_name, "r", encoding="utf-8") as task_file:
        data = json.load(task_file)
    if not isinstance(data, dict):
        raise ValueError("Task data must be a JSON object.")

    loaded_tasks: dict[int, dict[str, Any]] = {}
    for raw_task_id, task in data.items():
        try:
            task_id = int(raw_task_id)
        except (TypeError, ValueError) as error:
            raise ValueError("Task IDs must be positive integers.") from error
        if task_id <= 0 or task_id in loaded_tasks:
            raise ValueError("Task IDs must be unique positive integers.")
        if not _is_valid_task(task):
            raise ValueError(f"Invalid task record for ID {task_id}.")
        loaded_tasks[task_id] = task
    return loaded_tasks


def export_json(file_name: str = "tasks_export.json") -> None:
    """Export tasks to a separate, human-readable JSON file."""
    with open(file_name, "w", encoding="utf-8") as task_file:
        json.dump(TASKS, task_file, indent=2, ensure_ascii=False)


def main() -> None:
    """Run the demonstration workflow."""
    add_task("Submit lab report", "high")
    add_task("Buy groceries")
    add_task("Call plumber", "low")
    add_task("Book train tickets", "high")
    complete_task(2)
    complete_task(99)
    print("Pending tasks:", pending_tasks())
    print("Task id for 'plumber':", find_task("plumber"))
    print("Task id for 'gym':", find_task("gym"))

    pending = pending_tasks()
    if pending:
        print("Try this next:", secrets.choice(pending))
    else:
        print("No pending tasks to suggest.")

    save_tasks()
    restored = load_tasks()
    print("Tasks restored from file:", len(restored))
    export_json()
    print("Exported tasks to tasks_export.json")


if __name__ == "__main__":
    main()

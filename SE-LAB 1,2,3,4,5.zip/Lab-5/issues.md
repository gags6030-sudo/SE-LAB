# Static-analysis findings and fixes

Line numbers below refer to the unmodified `todo_manager.py` captured in `reports/before/`.

| Issue | Type | Line(s) | Description | Fix approach |
|---|---|---:|---|---|
| Shell command injection (Bandit B605) | Security — High | 55–57 | `os.system()` interpolated the recipient into a shell command, allowing shell metacharacters to alter the command. | Removed the unused email helper because the program has no configured mail service; this removes the shell execution path entirely. |
| Unsafe deserialization (Bandit B301/B403) | Security — Medium/Low | 3, 45–47 | `pickle.load()` can execute attacker-controlled code when loading an untrusted pickle file. | Replaced pickle serialization with JSON and added schema checks for loaded task records. JSON parsing does not execute object constructors. |
| Shared mutable default (Pylint W0102) | Correctness — Bug | 11–13 | `labels=[]` was reused between calls and the labels were not stored in each task record. | Changed the default to `None`, created a fresh list per call, and stored labels with each task. |
| Weak random generator (Bandit B311) | Security-analysis finding | 4, 70 | `random.choice()` uses a non-cryptographic PRNG; Bandit flags it even though a suggestion is not security-sensitive. | Used `secrets.choice()` so the finding is cleared without suppressing the analyzer. Added a guard for an empty task list. |
| Inconsistent return value (Pylint R1710) | Correctness | 33–37 | `findTask()` returned an ID on success but implicitly returned `None` on failure. | Made the `None` return explicit and added an optional return type. |
| Missing file encoding (Pylint W1514) | Portability | 51 | JSON output depended on the machine's default text encoding. | Opened JSON files with explicit UTF-8 encoding. |
| Naming, documentation, and whitespace findings (Pylint/Flake8) | Maintainability/style | Throughout; Flake8 12, 40, 69, 74 | CamelCase names, absent docstrings, and whitespace violations made the module less consistent and harder to read. | Renamed functions/variables to snake_case, added docstrings and a main guard, and formatted the code to satisfy Flake8. |

## Verification

- Before: Pylint **5.09/10**; Bandit **1 high, 1 medium, 2 low**; Flake8 reported four violations.
- After: Pylint **10.00/10**; Bandit reports **no issues**; Flake8 reports **no issues**.
- The demo still adds, completes, lists, searches, saves, and reloads tasks. The saved file is now JSON rather than pickle.

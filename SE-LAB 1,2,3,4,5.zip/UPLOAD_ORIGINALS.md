# Original binary files to upload manually

The GitHub file-push tool used for this commit accepts text files, not raw binary attachments. Upload these originals through GitHub's **Add file → Upload files** page if your teacher needs the exact PDFs, screenshots, ZIP, or videos:

- Lab 1: `PES1UG24CS165_SE_Lab 1.pdf`
- Lab 2: `Gagan_PES1UG24CS165_Jira_Lab2.pdf`
- Lab 3: `PES1UG24CS165_se_IMG.png` and `PES1UG24CS165_Lab3_Written_Justification.pdf`
- Lab 4: `Climber_Lab4_Final_Submission.zip` (contains the AI history PDF and before/after MP4s)
- Lab 5: `L5_37_todo_manager_deliverables.zip` (if a packaged copy is required in addition to the extracted text/source files)

# Self-Service Coffee Kiosk — Component Diagram

Components shown in the submitted hand-drawn diagram:

- **Customer Interface (Touch Screen)** — accepts customer input and connects to the order workflow through `IUserInput`.
- **Order Management Service** — coordinates order processing and requires menu data through `IMenuService` and payment processing through `IPaymentService`.
- **Menu Database** — provides menu data and pricing through `IMenuService`.
- **Payment Gateway** — processes payment and provides receipt information through `IReceiptService`.
- **Credit Card Network** — external dependency used by the payment gateway (`<<use>>`).
- **Receipt Printer** — receives receipt data through `IReceiptService`.

The sketch uses component symbols, provided/required interfaces, assembly connectors, and a dependency arrow.

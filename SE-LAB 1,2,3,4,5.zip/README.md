# Software Engineering Labs

Student submissions for Software Engineering Labs 1–5.

- **Lab 1:** Requirements engineering and UML use-case modelling for the Group Travel Expense Simplification Engine.
- **Lab 2:** Jira agile backlog and Sprint 1 simulation.
- **Lab 3:** Client-server architecture justification and self-service coffee kiosk component diagram.
- **Lab 4:** Climber game implementation and notes.
- **Lab 5:** Static analysis fixes for the assigned to-do manager.

The PDF, PNG, ZIP, and MP4 originals are not included in this text/source upload. See `UPLOAD_ORIGINALS.md` for the manual upload checklist.
